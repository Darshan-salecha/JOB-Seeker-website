<html>
<head><title>Drop down</title>
    <link rel="stylesheet" href="header.css" type="text/css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
    <body>
        <div class="menu-bar">
        <ul>
            <li class="active"><a href="homepage.php"><i class="fa fa-home" ></i>Home</a></li>
            <li><a href="#"><i class="fa fa-clone" ></i>Services</a>
                 <div class="sub-menu-1">
                 <ul>
                     <li><a href="#">Team</a></li>    
                     <li><a href="https://www.google.com/maps/place/JAYPEE+INSTITUTE+OF+INFORMATION+TECHNOLOGY/@28.6297338,77.3698669,17z/data=!3m1!4b1!4m5!3m4!1s0x390ce551491b3ce7:0x7335d9fcfd4d9db0!8m2!3d28.6297291!4d77.3720556">Address</a></li>
                     <li><a href="#">Education</a></li>    
                 </ul>
                 </div>
            </li>
            <li><a href="#"><i class="fa fa-users" ></i>Client</a>
             <div class="sub-menu-1">
                 <ul>
                     <li><a href="#">Team</a></li>    
                     <li><a href="#">Address</a></li>
                     <li><a href="#">Education</a></li>    
                 </ul>
                 </div>
            </li>
           
            <li><a href="#"><i class="fa fa-phone" ></i>Contact</a>
             <div class="sub-menu-1">
                 <ul>
                     <li><a href="#">Team</a></li>    
                     <li><a href="#">Address</a></li>
                     <li><a href="#">Education</a></li>    
                 </ul>
                 </div>
            </li>
			            <li><a href="form.php"><i class="fa fa-sign-in" ></i>Login</a></li>
						<li><a href="logout.php"><i class="fa fa-sign-out" ></i>Logout</a></li>
			           <li><a href="#"><i class="fa fa-upload" ></i>Resume</a>




        </ul>
        </div>
    </body>
</html>